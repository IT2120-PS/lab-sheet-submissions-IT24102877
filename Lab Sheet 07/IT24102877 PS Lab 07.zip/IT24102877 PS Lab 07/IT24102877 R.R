getwd()
setwd("C:\\Users\\94776\\Desktop\\IT24102877 PS Lab 07")

punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)


pexp(2, rate = 1/3)

1 - pnorm(130, mean = 100, sd = 15)

qnorm(0.95, mean = 100, sd = 15)
